<template>
  <div class="progress">
    <h4 class="progress-level">
      <span>42/50</span>
      <span>2</span>
    </h4>
    <div class="progress-container">
      <div class="progress-value" style="width: 20%"></div>
    </div>
  </div>
</template>
